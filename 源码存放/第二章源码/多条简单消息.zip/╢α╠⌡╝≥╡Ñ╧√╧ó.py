news = "你好！"
print(news)
      
news = "Hello!"
print(news)