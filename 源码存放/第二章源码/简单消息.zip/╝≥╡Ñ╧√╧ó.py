news = "你好！"
print(news)