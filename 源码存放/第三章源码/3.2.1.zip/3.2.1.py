motorcyles = ['honda', 'yamaha', 'suzuki']
print(motorcyles)
    
motorcyles[0] = 'ducati'
print(motorcyles)