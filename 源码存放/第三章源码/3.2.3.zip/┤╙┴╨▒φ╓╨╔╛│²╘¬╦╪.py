#使用del删除元素
motorcycles = ['honda', 'yamaha', 'suzuki']
print(motorcycles)
    
del motorcycles[0]
print(motorcycles)

motorcycles = ['honda', 'yamaha', 'suzuki']
del motorcycles[1]
print(motorcycles)

#--------------------------------------------------------------
#使用pop()删除元素

motorcycles = ['honda', 'yamaha', 'suzuki']
print(motorcycles)

popped_motorcycle = motorcycles.pop()
print(motorcycles)
print(popped_motorcycle)

#----------------------------------------------------------------
#弹出列表中任意位置的元素
motorcycles = ['honda', 'yamaha', 'suzuki']

first_owned = motorcycles.pop(0)
print(first_owned.title())

#----------------------------------------------------------------
#根据值删除列表中的元素
motorcycles = ['honda', 'yamaha', 'suzuki', 'ducati']
print(motorcycles)

motorcycles.remove('ducati')
print(motorcycles)