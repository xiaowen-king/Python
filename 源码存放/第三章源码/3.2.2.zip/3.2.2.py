#-----------------------------------------------------在列表末尾添加元素---------------------------------------------
motorcycles = ['honda', 'yamaha', 'suzuki']
print(motorcycles)
    
motorcycles.append('ducati')
print(motorcycles)

#-------------------------------------------
motorcycles = []
    
motorcycles.append('honda')
motorcycles.append('yamaha')
motorcycles.append('suzuki')
    
print(motorcycles)

#---------------------------------------------------在列表中插入元素------------------------------------------------
motorcycles = ['honda', 'yamaha', 'suzuke']
    
motorcycles.insert(0, 'ducati')
print(motorcycles)