#使用函数sorted()对列表临时排序
cars = ['bmw', 'audi', 'toyota', 'subaru']
print(cars)
print(sorted(cars))
print(cars)

#-------------------------------------------------------------
#使用函数sorted()对列表倒序临时排序
cars = ['bmw', 'audi', 'toyota', 'subaru']
print(sorted(cars,reverse=True))